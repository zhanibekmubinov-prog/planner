"""Утренняя сводка: состояние направлений (та же логика, что на Карте направлений во фронте),
дедлайны дня, просрочки, проверки поручений. Формирует текст для Telegram и HTML для почты."""
import html
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from sqlalchemy import select
from sqlalchemy.orm import Session
from . import models
from .config import settings

TZ = ZoneInfo(settings.app_timezone)
DAY = timedelta(days=1)
LEVELS = {"focus": "в фокусе", "ok": "норма", "fading": "ослабло", "lost": "упущено"}


def _utc(dt: datetime) -> datetime:
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt.astimezone(timezone.utc)


@dataclass
class DirReport:
    direction: models.Direction
    total: int = 0; done: int = 0; in_progress: int = 0; waiting: int = 0; backlog: int = 0
    overdue: list = field(default_factory=list)
    idle_days: int | None = None
    score: int = 0
    level: str = "focus"
    reasons: list = field(default_factory=list)


def build_report(d: models.Direction, tasks: list[models.Task], now: datetime) -> DirReport:
    """Порт buildReport() из frontend/src/Overview.tsx — держать формулы одинаковыми."""
    r = DirReport(direction=d)
    mine = [t for t in tasks if any(x.id == d.id for x in t.directions)]
    open_ = [t for t in mine if t.status != models.TaskStatus.done]
    r.total = len(mine)
    r.done = sum(t.status == models.TaskStatus.done for t in mine)
    r.in_progress = sum(t.status == models.TaskStatus.in_progress for t in mine)
    r.waiting = sum(t.status == models.TaskStatus.waiting for t in mine)
    r.backlog = sum(t.status == models.TaskStatus.backlog for t in mine)
    today = now.astimezone(TZ).date()
    r.overdue = [t for t in open_ if t.deadline and t.deadline < today]
    check_due = [t for t in open_ if t.next_check_at and _utc(t.next_check_at) <= now]
    stamps = [_utc(t.updated_at or t.created_at) for t in mine]
    if stamps:
        r.idle_days = (now - max(stamps)).days

    score = 0.0
    if not mine:
        score += 45; r.reasons.append("нет ни одной задачи")
    elif r.idle_days is not None:
        score += min(r.idle_days, 30) / 30 * 40
        if r.idle_days >= 14: r.reasons.append(f"нет движения {r.idle_days} дн.")
        elif r.idle_days >= 7: r.reasons.append(f"тихо уже {r.idle_days} дн.")
    if r.overdue: score += min(len(r.overdue) * 15, 30); r.reasons.append(f"просрочено {len(r.overdue)}")
    if check_due: score += min(len(check_due) * 10, 20); r.reasons.append(f"пропущено проверок {len(check_due)}")
    if open_ and r.in_progress == 0: score += 10; r.reasons.append("ничего не в работе")
    if open_ and all(not t.deadline and not t.next_check_at for t in open_): score += 5; r.reasons.append("ни у одной задачи нет срока")
    if d.status == models.DirectionStatus.paused:
        score = min(score, 15); r.reasons = ["на паузе"]
    r.score = round(min(score, 100))
    r.level = "focus" if r.score < 20 else "ok" if r.score < 45 else "fading" if r.score < 70 else "lost"
    return r


def _alive(items):
    """Без записей в корзине (soft-delete v0.8)."""
    return [x for x in items if getattr(x, "deleted_at", None) is None]


def undelivered(db: Session, user: models.User, now: datetime, since: timedelta = DAY) -> list[dict]:
    """Напоминания по моим задачам, которые планировщик не смог доставить за последние сутки (activity_log Reminder/gave_up)."""
    rows = db.scalars(select(models.ActivityLog).where(models.ActivityLog.entity_type == "Reminder", models.ActivityLog.action == "gave_up",
                                                      models.ActivityLog.created_at >= now - since)
                      .order_by(models.ActivityLog.created_at.desc()).limit(50)).all()
    out = []
    for r in rows:
        rem = db.get(models.Reminder, r.entity_id)
        if rem is None or rem.task is None or rem.task.owner_id != user.id:
            continue
        reason = (r.payload or {}).get("reason") or "не доставлено"
        detail = "; ".join(f"{k}: {v}" for k, v in (r.payload or {}).items() if k != "reason" and v != "ok")[:200]
        out.append({"task": rem.task, "fire_at": rem.fire_at, "reason": reason, "detail": detail})
    return out[:10]


def collect(db: Session, user: models.User, now: datetime | None = None) -> dict:
    now = now or datetime.now(timezone.utc)
    today = now.astimezone(TZ).date()
    directions = [d for d in _alive(db.scalars(select(models.Direction).where(models.Direction.owner_id == user.id)).all()) if d.status != models.DirectionStatus.archived]
    tasks = _alive(db.scalars(select(models.Task).where(models.Task.owner_id == user.id)).unique().all())
    # входящие поручения (мне поручили другие)
    pid = db.scalar(select(models.Person.id).where(models.Person.user_id == user.id))
    inbox = db.scalars(select(models.Delegation).where(models.Delegation.person_id == pid, models.Delegation.status == models.DelegationStatus.open)).all() if pid else []
    inbox = [d for d in inbox if d.task.owner_id != user.id and d.task.status != models.TaskStatus.done and getattr(d.task, "deleted_at", None) is None]
    open_ = [t for t in tasks if t.status != models.TaskStatus.done]
    reports = sorted((build_report(d, tasks, now) for d in directions),
                     key=lambda r: (r.direction.status == models.DirectionStatus.paused, -r.score))
    active = [r for r in reports if r.direction.status != models.DirectionStatus.paused]
    delegs = db.scalars(select(models.Delegation).join(models.Task).where(models.Delegation.status == models.DelegationStatus.open, models.Task.owner_id == user.id)).all()
    delegs = [x for x in delegs if getattr(x.task, "deleted_at", None) is None]
    return {
        "today": today,
        "reports": reports,
        "neglected": [r for r in active if r.level in ("fading", "lost")],
        "due_today": [t for t in open_ if t.deadline == today],
        "overdue": sorted([t for t in open_ if t.deadline and t.deadline < today], key=lambda t: t.deadline),
        "check_today": [t for t in open_ if t.next_check_at and _utc(t.next_check_at).astimezone(TZ).date() <= today],
        "deleg_due": [x for x in delegs if x.check_at and _utc(x.check_at).astimezone(TZ).date() <= today and x.task.status != models.TaskStatus.done],
        "open_count": len(open_),
        "inbox": inbox,
        "undelivered": undelivered(db, user, now),
    }


def _link(t: models.Task) -> str:
    return f"{settings.frontend_url.rstrip('/')}/?task={t.id}" if settings.frontend_url else ""


def render(data: dict) -> tuple[str, str, str]:
    """(subject, telegram_html, email_html)."""
    e = html.escape
    d: date = data["today"]
    title = f"Сводка на {d.strftime('%d.%m.%Y')}"
    neglected = data["neglected"]
    if not data["reports"] and not data.get("inbox"):
        return f"CIS Planner · {title}", f"☀️ <b>{title}</b>\nНаправлений и поручений пока нет — начните с направления в планнере.", f"<p>{title}: направлений и поручений пока нет.</p>"

    tg: list[str] = [f"☀️ <b>{title}</b>"]
    if neglected:
        tg.append("⚠️ <b>Требуют внимания:</b> " + ", ".join(e(r.direction.name) for r in neglected))
    else:
        tg.append("✅ Все направления в поле зрения")
    tg.append("")
    for r in data["reports"]:
        mark = {"focus": "🟢", "ok": "⚪", "fading": "🟠", "lost": "🔴"}[r.level]
        if r.direction.status == models.DirectionStatus.paused: mark = "⏸"
        line = f"{mark} <b>{e(r.direction.name)}</b> — открыто {r.total - r.done}, в работе {r.in_progress}"
        if r.overdue: line += f", просрочено {len(r.overdue)}"
        if r.reasons and r.level in ("fading", "lost"): line += f"\n    <i>{e(' · '.join(r.reasons))}</i>"
        tg.append(line)

    def tasks_block(header: str, items: list[models.Task], with_date=False):
        if not items: return
        tg.append(""); tg.append(f"<b>{header}</b>")
        for t in items[:10]:
            extra = f" (до {t.deadline.strftime('%d.%m')})" if with_date and t.deadline else ""
            link = _link(t)
            name = f"<a href=\"{link}\">{e(t.title)}</a>" if link else e(t.title)
            tg.append(f"• {name}{extra}")
        if len(items) > 10: tg.append(f"… и ещё {len(items) - 10}")

    tasks_block("📅 Дедлайн сегодня", data["due_today"])
    tasks_block("🚩 Просрочено", data["overdue"], with_date=True)
    tasks_block("🔁 Проверить сегодня", data["check_today"])
    if data["deleg_due"]:
        tg.append(""); tg.append("<b>👤 Спросить у людей</b>")
        for x in data["deleg_due"][:10]:
            tg.append(f"• {e(x.person.name)} — {e(x.task.title)}" + (f": {e(x.comment)}" if x.comment else ""))
    if data.get("inbox"):
        tg.append(""); tg.append("<b>📥 Мне поручено</b>")
        for x in data["inbox"][:10]:
            who = e(x.task.owner.name) if x.task.owner else "—"
            due = f" (до {x.task.deadline.strftime('%d.%m')})" if x.task.deadline else ""
            tg.append(f"• {e(x.task.title)}{due} — от {who}")
    if data.get("undelivered"):
        tg.append(""); tg.append("<b>⚠️ Не доставлено (напоминания)</b>")
        for x in data["undelivered"][:5]:
            tg.append(f"• {e(x['task'].title)} — {e(x['reason'])}" + (f" ({e(x['detail'])})" if x["detail"] else ""))
        tg.append("<i>Проверьте Telegram chat id в Профиле и адресатов поручений.</i>")
    tg.append(""); tg.append(f"Всего открытых задач: {data['open_count']}")
    tg_text = "\n".join(tg)

    # HTML для почты — тот же текст, аккуратнее оформлен
    body = tg_text.replace("\n", "<br>")
    mail = f"<div style='font-family:Georgia,serif;font-size:15px;line-height:1.5'>{body}</div>"
    return f"CIS Planner · {title}", tg_text, mail
